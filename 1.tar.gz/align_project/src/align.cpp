#include "align.h"
#include <string>
#include <vector>

using std::string;
using std::cout;
using std::endl;
using std::tuple;
using std::make_tuple;
using std::get;
using std::tie;
using std::nth_element;
using std::vector;

enum { MAXSHIFT = 15 };

class BoxFilterOp
{
    Matrix<double> ker;
public:
    uint radius = 0;
	BoxFilterOp(const Matrix<double> kernel) : ker(kernel), radius(kernel.n_rows) {};
    tuple<uint, uint, uint> operator()(const Image neighbourhood) const;
};

class MedianOp
{
public:
    uint radius = 0;
    MedianOp(const Matrix<double> kernel) : radius(kernel.n_rows) {};
    tuple<uint, uint, uint> operator()(const Image neighbourhood) const;
};

tuple<uint, uint, uint> BoxFilterOp::operator()(const Image neighbourhood) const
{
    double r = 0, g = 0, b = 0;
    double sum_r = 0, sum_g = 0, sum_b = 0;
    for (int i = 0; i < radius; i++)
        for (int j = 0; j < radius; j++)
		{
            tie(r, g, b) = neighbourhood(i, j);
            sum_r += r * ker(i, j);
            sum_g += g * ker(i, j);
            sum_b += b * ker(i, j);
        }
	if (sum_r < 0)
		sum_r = 0;
	if (sum_r > 255)
		sum_r = 255;
	if (sum_g < 0)
		sum_g = 0;
	if (sum_g > 255)
		sum_g = 255;
	if (sum_b < 0)
		sum_b = 0;
	if (sum_b > 255)
		sum_b = 255;
	return make_tuple(sum_r, sum_g, sum_b);
}

tuple<uint, uint, uint> MedianOp::operator()(const Image neighbourhood) const
{
    uint r = 0, g = 0, b = 0;
    vector<uint> v_r, v_g, v_b;
    for (int i = 0; i < radius; i++)
        for (int j = 0; j < radius; j++)
		{
            tie(r, g, b) = neighbourhood(i, j);
            v_r.push_back(r);
            v_g.push_back(g);
            v_b.push_back(b);
        }
	sort(v_r.begin(), v_r.end());
	sort(v_g.begin(), v_g.end());
	sort(v_b.begin(), v_b.end());
	return make_tuple(v_r[v_r.size()/2], v_g[v_g.size()/2], v_b[v_b.size()/2]);
}

Image img_shift(const Image src_image, int y, int x) { //shift the image with the params
	Image ans(src_image.n_rows, src_image.n_cols);
	if (y <= 0)
	{
		for (int j = -y; j < ans.n_rows; j++)
			if (x > 0)
				for (int i = x; i < ans.n_cols; i++)
					ans(j,i)=src_image(j+y,i-x);
			else
				for (int i = 0; i < ans.n_cols+x; i++)
					ans(j,i)=src_image(j+y,i-x);
	}
	if (y > 0)
	{
		for (int j = 0; j < ans.n_rows-y; j++)
			if (x > 0)
				for (int i = x; i < ans.n_cols; i++)
					ans(j,i)=src_image(j+y,i-x);
			else
				for (int i = 0; i < ans.n_cols+x; i++)
					ans(j,i)=src_image(j+y,i-x);
	}
	return ans;
}

double MSE(const Image fir, const Image sec, int x, int y){ //metric MSE
	int height = fir.n_rows - abs(y);
	int width = fir.n_cols - abs(x);
	double sum = 0, diff = 0;
	if (x < 0 && y > 0)
		for (int j = 0; j < height; j++)
			for (int i = 0; i < width; i++)
			{
				diff = (int)get<0>(fir(j,i))-(int)get<0>(sec(j+y,i-x));
				sum += diff * diff;
			}
	if (x < 0 && y <= 0)
		for (int j = 0; j < height; j++)
			for (int i = 0; i < width; i++)
			{
				diff = (int)get<0>(fir(j-y,i))-(int)get<0>(sec(j,i-x));
				sum += diff*diff;
			}
	if (x >= 0 && y > 0)
		for (int j = 0; j < height; j++)
			for (int i = 0; i < width; i++)
			{
				diff = (int)get<0>(fir(j,i+x))-(int)get<0>(sec(j+y,i));
				sum += diff*diff;
			}
	if (x >= 0 && y <= 0)
		for (int j = 0; j < height; j++)
			for (int i = 0; i < width; i++)
			{
				diff = (int)get<0>(fir(j-y,i+x))-(int)get<0>(sec(j,i));
				sum += diff*diff;
			}
	return sum / (height*width);
}

void optimal(const Image fir, const Image sec, int &x, int &y) { //search optimal shift
	double curr, min = MSE(fir, sec, -MAXSHIFT, -MAXSHIFT);
	for (int i = -MAXSHIFT; i <= MAXSHIFT; i++)
		for (int j = -MAXSHIFT; j <= MAXSHIFT; j++)
		{
			curr = MSE(fir, sec, i, j);
			if (curr < min)
			{
				min = curr;
				x = i;
				y = j;
			}
		}
}

Image align(Image srcImage, bool isPostprocessing, string postprocessingType, double fraction, bool isMirror, 
            bool isInterp, bool isSubpixel, double subScale)
{
	Image B = srcImage.submatrix(0, 0, srcImage.n_rows / 3, srcImage.n_cols);
	Image G = srcImage.submatrix(srcImage.n_rows / 3, 0, srcImage.n_rows / 3, srcImage.n_cols);
	Image R = srcImage.submatrix(srcImage.n_rows * 2 / 3 , 0, srcImage.n_rows / 3, srcImage.n_cols);
	int x = 0, y = 0;
	if (isSubpixel)
	{
			B = resize(B, subScale);
			G = resize(G, subScale);
			R = resize(R, subScale);		
	}
	optimal(R, B, x, y);
	B = img_shift(B, y, x);
	optimal(R, G, x, y);
	G = img_shift(G, y, x);
	int rows = B.n_rows, cols = B.n_cols;   
	Image ans(B.n_rows, B.n_cols);
	for (int i = 0; i < rows; i++)
		for (int j = 0; j < cols; j++)
			if ((get<0>(R(i,j))!=0) && (get<0>(G(i,j))!=0) && (get<0>(B(i,j))!=0))
				ans(i, j) = make_tuple(get<0>(R(i, j)), get<1>(G(i, j)), get<2>(B(i, j)));
	if (isSubpixel)
		return resize(ans, 1/subScale);
	if (isPostprocessing) 
	{
		if (postprocessingType == "--gray-world")
			return gray_world(ans);
		else 
			if (postprocessingType == "--unsharp")
				return unsharp(ans);
			else
				return autocontrast(ans,fraction);			
	}
	else
		return ans;
}

Image sobel_x(Image src_image) {
    Matrix<double> kernel = {{-1, 0, 1},
                             {-2, 0, 2},
                             {-1, 0, 1}};
    return custom(src_image, kernel);
}

Image sobel_y(Image src_image) {
    Matrix<double> kernel = {{ 1,  2,  1},
                             { 0,  0,  0},
                             {-1, -2, -1}};
    return custom(src_image, kernel);
}

Image unsharp(Image src_image) {
	Matrix<double> kernel = {{-1.0/6, -2.0/3, -1.0/6},
							 {-2.0/3, 13.0/3, -2.0/3},
							 {-1.0/6, -2.0/3, -1.0/6}}; 
	return custom(src_image, kernel);
}

Image gray_world(Image src_image) {
	int S_R = 0, S_G = 0, S_B = 0, S;
	for (int i = 0; i < src_image.n_rows; i++)
		for (int j = 0; j < src_image.n_cols; j++)
		{
			S_R += get<0>(src_image(i, j));
			S_G += get<1>(src_image(i, j));
			S_B += get<2>(src_image(i, j)); 
		}
	S_R /= src_image.n_rows * src_image.n_cols;
	S_G /= src_image.n_rows * src_image.n_cols;
	S_B /= src_image.n_rows * src_image.n_cols;
	S = (S_R + S_G + S_B) / 3;
	for (int i = 0; i < src_image.n_rows; i++)
		for (int j = 0; j < src_image.n_cols; j++)
		{
			get<0>(src_image(i, j)) = get<0>(src_image(i, j)) * S / S_R;
			get<1>(src_image(i, j)) = get<1>(src_image(i, j)) * S / S_G;
			get<2>(src_image(i, j)) = get<2>(src_image(i, j)) * S / S_B;
			if (get<0>(src_image(i, j)) > 255)
				get<0>(src_image(i, j)) = 255;
			if (get<1>(src_image(i, j)) > 255)
				get<1>(src_image(i, j)) = 255;
			if (get<2>(src_image(i, j)) > 255)
				get<2>(src_image(i, j)) = 255;
		}
    return src_image;
}

Image resize(Image src_image, double scale) {
	if (scale > 1)
	{
		Image Big(src_image.n_rows*scale, src_image.n_cols*scale);
		for (int i = 0; i < src_image.n_rows; i++)
			for (int j = 0; j < src_image.n_cols; j++)
				for (int k = 0; k < scale; k++)
					for (int l=0 ; l < scale; l++)
						Big(i*scale+k, j*scale+l) = src_image(i,j);  	
		return Big;
	}
	Image Little(double(src_image.n_rows)*scale, double(src_image.n_cols)*scale);
	for (int i = 0; i < int(src_image.n_rows); i += (1.0/scale))
		for (int j = 0; j < int(src_image.n_cols); j += (1.0/scale))
			Little(i*scale,j*scale) = src_image(i,j);
	return Little;
}

Image custom(Image src_image, Matrix<double> kernel) {
    // Function custom is useful for making concrete linear filtrations
    // like gaussian or sobel. So, we assume that you implement custom
    // and then implement other filtrations using this function.
    // sobel_x and sobel_y are given as an example.
	return src_image.unary_map(BoxFilterOp(kernel));
    //return src_image;
}

Image autocontrast(Image src_image, double fraction) {
	int Y;
	uint* hist;
	hist = new uint[256];
	for (int i = 0; i < 256; i++)
		hist[i] = 0;
	for (int i = 0; i < src_image.n_rows; i++)
		for (int j = 0; j < src_image.n_cols; j++)
		{
			Y = 0.2125 * get<0>(src_image(i, j)) + 0.7154 * get<1>(src_image(i, j)) + 0.0721 * get<2>(src_image(i, j));            
			if (Y > 255)
				Y = 255;
			hist[Y] += 1;
        }
	double left_margin = fraction * src_image.n_cols * src_image.n_rows;
	double right_margin = (1 - fraction) * src_image.n_cols * src_image.n_rows;  
	uint Y_min = 0, Y_max = 255, count = 0;
	for (int i = 0; i < 256; i++)
	{
		if(count <= left_margin && count + hist[i] > left_margin)
			Y_min = i;
		if(count <= right_margin && count + hist[i] > right_margin)
		{
			Y_max = i;
			break;
		}
		count += hist[i];
    }
	Image result(src_image.n_rows, src_image.n_cols);
	double k = 255.0 / (Y_max - Y_min);
	int r, g, b;
	for (int i = 0; i < src_image.n_rows; i++)
		for (int j = 0; j < src_image.n_cols; j++)
		{
			tie(r, g, b) = src_image(i, j);
			r = (r - Y_min) * k;
			g = (g - Y_min) * k;
			b = (b - Y_min) * k;
			if (r < 0)
				r = 0;
			if (r > 255)
				r = 255;
			if (g < 0)
				g = 0;
			if (g > 255)
				g = 255;
			if (b < 0)
				b = 0;
			if (b > 255)
				b = 255;
			result(i, j) = make_tuple(r, g, b);
		}
    return result;
}

Image gaussian(Image src_image, double sigma, int radius)  {
    return src_image;
}

Image gaussian_separable(Image src_image, double sigma, int radius) {
    return src_image;
}

Image median(Image src_image, int radius) {
    return src_image.unary_map(MedianOp(uint(radius)));
}

Image median_linear(Image src_image, int radius) {
    return src_image;
}

Image median_const(Image src_image, int radius) {
    return src_image;
}

Image canny(Image src_image, int threshold1, int threshold2) {
    return src_image;
}
