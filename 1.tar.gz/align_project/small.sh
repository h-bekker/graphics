#!/bin/bash
make
k=0
for i in ~/Downloads/small/*; do
	./build/bin/align ${i} /home/bekker/small$k.bmp --align
	./build/bin/align ${i} /home/bekker/smallgray$k.bmp --align --gray-world
	./build/bin/align ${i} /home/bekker/smallunsharp$k.bmp --align --unsharp
	$((k+=1))
	echo $k
done;
