#!/bin/bash
make
k=0
for i in ~/Downloads/small/*; do
	./build/bin/align ${i} /home/bekker/small$k.bmp --align
	./build/bin/align ${i} /home/bekker/smallgray$k.bmp --align --gray-world
	./build/bin/align ${i} /home/bekker/smallunsharp$k.bmp --align --unsharp
	./build/bin/align ${i} /home/bekker/smallcontrast$k.bmp --align --autocontrast 0.1
	./build/bin/align ${i} /home/bekker/smallsubpixel$k.bmp --align --subpixel
	./build/bin/align /home/bekker/small$k.bmp /home/bekker/median$k.bmp --median 5
	$((k+=1))
	echo $k
done;
